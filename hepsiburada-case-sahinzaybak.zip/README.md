# React vote app

## Build Setup

```bash
# install dependencies
$ npm install

# serve with hot reload at localhost:3000
$ npm start
```

<br>
<div align="center">
  <img src="https://image.flaticon.com/teams/slug/smashicons.jpg" width="80">
  <h3><i>Developer by Şahin ZAYBAK </i></h3>
  <hr/>
</div>

